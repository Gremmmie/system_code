package operation;

import book.BookList;

/**
 * @Author 12629
 * @Date 2022/4/10 11:59
 * @Description：
 */
public interface IOPeration {
    void work(BookList bookList);
}
