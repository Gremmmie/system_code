package operation;
import book.BookList;

/**
 * Created with IntelliJ IDEA.
 * Description: Hello,I would appreciate your comments~
 * User:
 * Date: -04-12
 * Destination: 退出系统
 */
public class ExitOperation implements IOperation {

    public void work(BookList bookList) {

        //有可能  需要销毁，或者使用到 这个数组当中的所有的数据
        System.out.println("退出系统！");
        /*int currentSize = bookList.getUsedSize();
        for (int i = 0; i < currentSize; i++) {
            bookList.setBooks(i,null);
        }*/
        System.exit(0);
    }

}