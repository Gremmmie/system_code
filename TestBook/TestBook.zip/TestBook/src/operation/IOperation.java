package operation;
import book.BookList;
/**
 * Created with IntelliJ IDEA.
 * Description: Hello,I would appreciate your comments~
 * User:
 * Date: -04-12
 * Destination:接口，用来实现各类操作
 */
public interface IOperation {
    void work(BookList bookList);
}
